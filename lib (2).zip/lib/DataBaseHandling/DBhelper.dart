import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
class DBhelper {
  static Database? _database;
  static const String dbname = 'register_db';
  static const String tablename = 'usertable';

  DBhelper._privateConstructor();

  static DBhelper instance = DBhelper._privateConstructor();

  Future<Database> _initDatabase() async {
    String dbPath = join(await getDatabasesPath(), dbname);
    return await openDatabase(dbPath, version: 1, onCreate: _onCreate);
  }

  Future<Database> get database async {
    if (_database != null) {
      return _database!;
    }
    else {
      _database = await _initDatabase();
      return _database!;
    }
  }

  Future<void> _onCreate(Database db, int version) async {
    var sql = "create table $tablename(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,email TEXT UNIQUE,password TEXT,mobile TEXT UNIQUE,role TEXT UNIQUE)";
    await db.execute(sql);
  }
}