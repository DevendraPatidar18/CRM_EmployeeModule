class User {
  int? id;
  String? name;
  String? email;
  String? password;
  String? mobile;
  String? role;

  User(
      {this.id, required this.name, required this.email, required this.password, required this.mobile, required this.role});

  Map<String, dynamic> toMap() {
    return {
      "name": name,
      "email": email,
      "password": password,
      "mobile":mobile,
      "role": role,
    };
  }

  factory User.fromMap(Map<String, dynamic> obj)
  {
    return User(
      id: obj['id'] ?? 0,
      name: obj['name'],
      email: obj['email'],
      password: obj['password'],
      mobile: obj['mobile'],
      role: obj['role'],
    );
  }
}