import 'package:crm/DataBaseHandling/Model/User.dart';
import 'package:sqflite/sqflite.dart';
import 'DBhelper.dart';

class UserDao
{
  Future<int> registerUser(User user) async
  {
    DBhelper helper =  DBhelper.instance;
    print("Helper Object is : ${helper}");
    Database db = (await helper.database) as Database;
    print("DataBase Object is : ${db}");

    return await db.insert(DBhelper.tablename, user.toMap());
  }
}