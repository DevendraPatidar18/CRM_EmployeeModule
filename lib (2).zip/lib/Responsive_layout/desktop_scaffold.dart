import 'package:flutter/material.dart';
import '../Constants/constants.dart';
import '../Pages/Call_history_page.dart';
import '../Pages/Dashboard.dart';
import '../Pages/Profile_page.dart';
import '../Pages/View_product_services.dart';
import '../Pages/enquires_page.dart';
class Desktop_Scaffold extends StatefulWidget {
  const Desktop_Scaffold({super.key});

  @override
  State<Desktop_Scaffold> createState() => _Desktop_ScaffoldState();
}

class _Desktop_ScaffoldState extends State<Desktop_Scaffold> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          toolbarHeight: 40,
          iconTheme: const IconThemeData(color: Colors.white),
          backgroundColor: Colors.blue[400],

          title: const Text(
            "Home",
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          actions: <Widget>[
            InkWell(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => const Profile()));
              },
              child: CircleAvatar(
                child: Image.asset(
                  'assets/drawable/profileicon.png',
                  height: 40,
                  width: 40,
                ),
              ),
            ),
            const SizedBox(
              width: 10,
            )
          ],
        ),
        backgroundColor: mydefaltbackground,
        drawer: myDrawer,
        body: DefaultTabController(
          length: 4,
          child:  Scaffold(
            appBar:  AppBar(
              automaticallyImplyLeading: false,
              iconTheme: const IconThemeData(color: Colors.white,),
              flexibleSpace:  Container(
                decoration: BoxDecoration(color: Colors.blue[400]),
              ),
              title: const TabBar(
                tabs: [
                  Tab(
                    icon: Icon(
                      Icons.home,
                      color: Colors.white,
                    ),
                  ),
                  Tab(
                      icon: ImageIcon(AssetImage('assets/drawable/enquiry_icon.png'),color: Colors.white,)

                  ),
                  Tab(
                    icon: Icon(
                      Icons.view_in_ar_rounded,
                      color: Colors.white,
                    ),
                  ),
                  Tab(
                    icon: Icon(
                      Icons.call,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
            body: const TabBarView(children: [
              Dashboard(),
              EnquiryPage(),
              View_product(),
              Call_history_page(),

            ]),
          ),

        )


      //   body: Row(
      //   children: [
      //      myDrawer,
      //   ],
      //
      // )
    );
  }
}
