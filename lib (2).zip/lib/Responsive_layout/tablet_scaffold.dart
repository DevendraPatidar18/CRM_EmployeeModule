import 'package:flutter/material.dart';
import '../Constants/constants.dart';
import '../Pages/Profile_page.dart';
class Tablet_Scaffold extends StatefulWidget {
  const Tablet_Scaffold({super.key});

  @override
  State<Tablet_Scaffold> createState() => _Tablet_ScaffoldState();
}

class _Tablet_ScaffoldState extends State<Tablet_Scaffold> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:  AppBar(backgroundColor: Colors.blue[400],
        title: const Text(""),
        actions: <Widget>[
          InkWell(
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const Profile()));
            },
            child: Image.asset('assets/drawable/emp_profile.png',
              height: 40,
              width: 40,
              color: Colors.black54,),
          ),
          const SizedBox(width: 10,)
        ],

      ),
      backgroundColor: mydefaltbackground,
      drawer: myDrawer,
    );
  }
}
