import 'package:flutter/material.dart';

import '../Pages/Profile_page.dart';

class DefaultAppBar extends StatelessWidget {
  const DefaultAppBar({super.key,required this.pageName});
  final String pageName;

  @override
  PreferredSizeWidget build(BuildContext context) {
    return AppBar(
      backgroundColor: Colors.blue[400],
      title:  Text(pageName),
      actions: <Widget>[
        InkWell(
          onTap: () {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => const Profile()));
          },
          child: Image.asset('assets/drawable/emp_profile.png',
            height: 40,
            width: 40,
            color: Colors.black54,),
        ),
        const SizedBox(width: 10,)
      ],


    );
  }
}
