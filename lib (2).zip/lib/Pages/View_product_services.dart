import 'package:crm/Pages/Product_Detail.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

import '../Constants/constants.dart';

class View_product extends StatelessWidget {
  const View_product({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        image: DecorationImage(image: AssetImage('assets/drawable/screenbackground.png'),
        fit: BoxFit.fill)
      ),
      child: SingleChildScrollView(
        child:Column(
          children: [
            SizedBox(height: 8),
            SearchBar(
              keyboardType: TextInputType.number,
              leading: const Icon(
                Icons.search,
                color: Colors.white,
              ),
              elevation: const MaterialStatePropertyAll(5),
              textStyle:
              const MaterialStatePropertyAll(TextStyle(color: Colors.white)),
              backgroundColor: MaterialStatePropertyAll(Colors.lightBlueAccent[200]),
              hintText: 'Search Product',
            ),
            SizedBox(height: 14),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(30))
              ),
              child: ListView.separated(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: 20,
                itemBuilder: (context, index) {
                  return ListTile(
                    onTap: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => ProductDetail() ));
                    },
                    tileColor: mydefaltbackground,
                    leading: CircleAvatar(backgroundColor: Colors.blueAccent[100],
                      child: Text('ID'),
                    ),
                    title: const Text('Product name'),
                    subtitle: const Text('Product Status'),
                    trailing: const Text('Price'),
                  );
                },
                separatorBuilder: (context, index) {
                  return const Divider(
                    thickness: 1,
                    height: 1,
                  );
                },
              ),
            ),

          ],
        )

      ),
    );
  }
  Widget avilableProduct(BuildContext context){
    return  ListView.separated(
      scrollDirection: Axis.horizontal,
    itemCount: 8,
    itemBuilder: (context,index){
      return Container(
    height: 70,
    width: 200,
    padding: EdgeInsets.all(10),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.all(Radius.circular(20)),
      color: Colors.blue[400]
    ),

    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
    crossAxisAlignment: CrossAxisAlignment.center,

    children: [
      Text('Product Name',style: TextStyle(color: Colors.white),),
    Text('Number',style: TextStyle(color: Colors.white))
    ],
    )
      );
    },
    separatorBuilder: (context,index){
        return SizedBox(width: 10);},

    );


  }
}
