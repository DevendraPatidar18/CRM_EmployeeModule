import 'dart:async';

import 'package:crm/Pages/Home_page.dart';
import 'package:crm/Pages/Login_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  @override
  void initState() {
    super.initState();
    // Simulate a delay for 2 seconds before navigating to the main screen
    Timer(Duration(seconds: 2),getSavedData);
  }
  void getSavedData() async{
    SharedPreferences s = await SharedPreferences.getInstance();
    String? email= s.getString('email');
    String? pass= s.getString('pass');
    if(email != null && 'pass' != null){
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => Home()));
    }
    else{
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => LoginPage(),));
    }
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Colors.blue,
        body:  Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text("Welcome Users",style: TextStyle(color: Colors.white),)
            ],
                  ),),);
  }
}
