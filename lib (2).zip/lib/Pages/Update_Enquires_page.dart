import 'package:flutter/material.dart';
import '../Constants/constants.dart';
import 'Profile_page.dart';
class Update extends StatelessWidget {
  const Update({super.key});

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
     appBar: AppBar(backgroundColor: Colors.blue[400],
       title: const Text(""),
       actions: <Widget>[
         InkWell(
           onTap: () {
             Navigator.push(context,
                 MaterialPageRoute(builder: (context) => const Profile()));
           },
           child: Image.asset('assets/drawable/emp_profile.png',
             height: 40,
             width: 40,
             color: Colors.black54,),
         ),
         const SizedBox(width: 10,)
       ],

     ),
      drawer: myDrawer,
      body: const  Center(
        child: Text('Call History Under Development'),
      ),

    );

  }
}
