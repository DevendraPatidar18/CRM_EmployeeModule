import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';



class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();

}

class _ProfileState extends State<Profile> {
 

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.blue[400],
        title: const Text('Profile',style: TextStyle(color: Colors.white)),
      ),
      body: Container(
        decoration: BoxDecoration(
            image: DecorationImage(image: AssetImage('assets/drawable/screenbackground.png'),
                fit: BoxFit.fill)
        ),
        padding: const EdgeInsets.only(top: 40,right: 5,left: 5),
        child: Column(
          crossAxisAlignment:CrossAxisAlignment.center,
          children: [
             Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 150,
                  height: 150,
                  child:CircleAvatar(
                    radius: 50,
                    child: Image.asset('assets/drawable/profileicon.png',width: 140,height: 140)
                  ),

                  )

            ]),
            const SizedBox(height: 15),
            ElevatedButton(onPressed: () {

            }, child: const Text('Change Image',style: TextStyle(color: Colors.black),)),

             ClipRRect(
               borderRadius: BorderRadius.all(Radius.circular(30)),
               child: Card(

                 elevation: 5,
                 child: ListTile(
                  tileColor: Colors.grey[300],
                  leading: Icon(Icons.person),
                  title: Text('Mr Devid',style: TextStyle(fontWeight: FontWeight.w600),),
                  subtitle: Text('Name'),
                             ),
               ),
             ),
            const SizedBox(height: 3),
             ClipRRect(
               borderRadius:  BorderRadius.all(Radius.circular(30)),
               child: Card(
                 elevation: 5,
                 child: ListTile(
                  tileColor: Colors.grey[300],
                   leading: Icon(Icons.perm_identity),
                  title: Text('21',style: TextStyle(fontWeight: FontWeight.w600),),
                  subtitle: Text('Id'),
                             ),
               ),
             ),
            const SizedBox(height: 3),
            ClipRRect(
              borderRadius:  BorderRadius.all(Radius.circular(30)),
              child: Card(
              elevation: 5,
              child: ListTile(
                tileColor: Colors.grey[300],
                leading: Icon(Icons.accessibility),
                title: Text('Telicaller',style: TextStyle(fontWeight: FontWeight.w600)),
                subtitle: Text('Role'),
              ),
            ),
            ),
            const SizedBox(height: 3),
            ClipRRect(
              borderRadius:  BorderRadius.all(Radius.circular(30)),
              child: Card(
                elevation: 5,
                child: ListTile(
                  tileColor: Colors.grey[300],
                  title: Text('Leptop',style: TextStyle(fontWeight: FontWeight.w600),),
                  subtitle: Text('Experties'),
                ),
              ),
            ),


          ],
        ),
      ),
    );
  }


  }
 