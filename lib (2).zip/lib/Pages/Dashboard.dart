import 'dart:convert';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:crm/Pages/Enquiry_Detail_page.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher_string.dart';
import 'package:http/http.dart'as http;
import '../Pages/Login_page.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});

  @override
  State<Dashboard> createState() => _DashboardState();
}
List<dynamic> users = [];
class _DashboardState extends State<Dashboard> {
  void fatchEnquiry() async {
    const url = 'https://randomuser.me/api/?results=20';
    final uri = Uri.parse(url);
    final response = await http.get(uri);
    final body = response.body;
    final json = jsonDecode(body);
    users = json['results'];
    print('Fatching successful');
  }

  List<Text> grildTitle = [
    const Text('Make Call',style:TextStyle(color: Colors.white, fontSize: 16),),
    const Text('Make Call',style: TextStyle(color: Colors.white, fontSize: 16),),
    const Text('Make Email',style: TextStyle(color: Colors.white, fontSize: 16),),
    const Text('Make Call',style: TextStyle(color: Colors.white, fontSize: 16),),
    const Text('Messages',style: TextStyle(color: Colors.white, fontSize: 16),),
    const Text('Make Call',style: TextStyle(color: Colors.white, fontSize: 16),),
  ];
  List<Widget> grildIcon = [
    const Icon(Icons.call,size: 30,color: Colors.white,),
    const Icon(Icons.call,size: 30,color: Colors.white,),
    const Icon(Icons.email,size: 30,color: Colors.white,),
    const Icon(Icons.call,size: 30,color: Colors.white,),
    const Icon(Icons.message_outlined,size: 30,color: Colors.white,),
    const Icon(Icons.call,size: 30,color: Colors.white,)
  ];
  List imageList = [
    {"id": 1, "imagePath": 'assets/Slider_images/img.png'},
    {"id": 2, "imagePath": 'assets/Slider_images/task.png'},
    {"id": 3, "imagePath": 'assets/Slider_images/events.png'},
    {"id": 4, "imagePath": 'assets/Slider_images/new_product.png'},
  ];

  CarouselController carouselController = CarouselController();
  var currentIndex = 0;
  @override
  Widget build(BuildContext context) {
    fatchEnquiry();
    final screenwidth = MediaQuery.of(context).size.width;
    return Container(
      width: screenwidth,
      decoration: const BoxDecoration(
          image: DecorationImage(
              image: AssetImage('assets/drawable/screenbackground.png'),
              fit: BoxFit.fill)),
      child: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            const SizedBox(height: 10),
            SearchBar(
              keyboardType: TextInputType.number,
              leading: const Icon(
                Icons.search,
                color: Colors.white,
              ),
              elevation: const MaterialStatePropertyAll(5),
              textStyle: const MaterialStatePropertyAll(
                  TextStyle(color: Colors.white)),
              backgroundColor: MaterialStatePropertyAll(Colors.blue[400]),
              hintText: 'Search Enquiry',
            ),
            const SizedBox(height: 10),
            // horizontalScrollView(context),
            imageSlider(context,screenwidth),
            Container(
              alignment: Alignment.center,
              height: 277,
              child: GridView.count(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.all(10),
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                children: List.generate(6, (index) {
                  return Card(
                    elevation: 10,
                    color: Colors.blue[400],
                    child: InkWell(
                      onTap: () {
                      switch(index) {
                        case 0 : launchUrlString("tel://");break;
                        case 1://launchUrlString("tel://");break;
                        case 2:launchUrlString("mailto:");break;
                        case 3://launchUrlString("tel://");break;
                        case 4:launchUrlString("sms:");break;
                        case 5://launchUrlString("tel://");break;
                      }
                      },

                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const SizedBox(
                              height: 10,
                            ),
                            grildIcon[index],
                            grildTitle[index],
                          ]),
                    ),
                  );
                }),
              ),
            ),

            Container(
                alignment: Alignment.topLeft,
                padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
                child: Text('Recent',
                    style: TextStyle(
                      fontSize: 24,
                      color: Colors.blue[400],
                      fontWeight: FontWeight.bold,
                    ))),
            const SizedBox(height: 10),

            Container(
                width: 393,
                height: 450,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    borderRadius: const BorderRadius.all(Radius.circular(30)),
                    color: Colors.blue[400]),
                child: ListView.separated(
                    itemCount: users.length,

                    itemBuilder: (context, index) {
                      final user = users[index];
                      final userName = user['name']['first'];
                      return ListTile(
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const EnquiryDetail()));
                        },
                        tileColor: Colors.white,
                        textColor: Colors.white,
                        iconColor: Colors.white,
                        leading: CircleAvatar(
                            backgroundColor: Colors.white,
                            child: Text(
                              'ID',
                              style: TextStyle(color: Colors.blue[400]),
                            )),
                        title: Text(userName),
                        subtitle: const  Text(
                          'Time',
                          style: TextStyle(color: Colors.white),
                        ),
                        trailing: const Icon(Icons.more_vert),
                      );
                    },
                    separatorBuilder: (context, index) {
                      return const Divider(
                        thickness: 1,
                        height: 1,
                      );
                    }))
          ],
        ),
      ),
    );
  }
  Widget imageSlider(BuildContext context,width) {
    return Stack(
      children: [
        CarouselSlider(
          items: imageList
              .map((item) => Container(
                  alignment: Alignment.center,
                  width: width/1.1,
                  height: 200,
                  decoration:  BoxDecoration(
                    borderRadius: const BorderRadius.all(Radius.circular(20)),
                    image: DecorationImage(
                        image: AssetImage(item['imagePath']),
                        fit: BoxFit.fill),
                  ),
              child: Text(
                '',
                style: TextStyle(
                    fontSize: 32,
                    color: Colors.grey[500],
                    fontWeight: FontWeight.bold),
              ),
          ))
              .toList(),
          carouselController: carouselController,
          options: CarouselOptions(
              scrollPhysics: const BouncingScrollPhysics(),
              autoPlay: true,
              aspectRatio: 2,
              viewportFraction: 1,
              onPageChanged: (index, reason) {
                setState(() {
                  currentIndex = index;
                });
              }),
        ),
        Positioned(
            bottom: 8.0,
            left: 0,
            right: 0,
            child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: imageList.asMap().entries.map((entry) {
                  return GestureDetector(
                    onTap: () {
                      carouselController.animateToPage(entry.key);
                    },
                    child: Container(
                      width: currentIndex == entry.key ? 15 : 7,
                      height: 7.0,
                      margin: const EdgeInsets.symmetric(horizontal: 3),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: currentIndex == entry.key
                            ? Colors.indigo
                            : Colors.teal,
                      ),
                    ),
                  );
                }).toList()))
      ],
    );
  }
}
