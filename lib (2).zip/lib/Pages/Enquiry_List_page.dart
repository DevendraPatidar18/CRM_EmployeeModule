import 'package:crm/Pages/Enquiry_Detail_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class Enquiey_List extends StatefulWidget {
  const Enquiey_List({super.key});

  @override
  State<Enquiey_List> createState() => _Enquiey_ListState();
}

class _Enquiey_ListState extends State<Enquiey_List> {
  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    return Container(
      width: screenWidth,
      decoration: const BoxDecoration(
          image: DecorationImage(
              image: AssetImage('assets/drawable/screenbackground.png'),
              fit: BoxFit.fill)),
      child: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 8),
            SearchBar(
              keyboardType: TextInputType.number,
              leading: const Icon(
                Icons.search,
                color: Colors.white,
              ),
              elevation: const MaterialStatePropertyAll(5),
              textStyle: const MaterialStatePropertyAll(
                  TextStyle(color: Colors.white)),
              backgroundColor:
                  MaterialStatePropertyAll(Colors.lightBlueAccent[200]),
              hintText: 'Search Enquiry',
            ),
            SizedBox(height: 14),
            Container(
              child: ListView.separated(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemBuilder: (context, index) {
                    return ListTile(
                      selectedTileColor: Colors.lightBlueAccent[200],
                      leading: CircleAvatar(
                        child: Text('Id'),
                        backgroundColor: Colors.blueAccent[100],
                      ),
                      textColor: Colors.black,
                      title: Text('Customer Name'),
                      subtitle: Text('Status'),
                      trailing: Text('Date'),
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => EnquiryDetail(),
                            ));
                      },
                    );
                  },
                  separatorBuilder: (context, index) {
                    return const Divider(
                      thickness: 1,
                      height: 1,
                    );
                  },
                  itemCount: 20),
            ),
          ],
        ),
      ),
    );
  }
}
