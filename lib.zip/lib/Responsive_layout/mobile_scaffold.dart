import 'package:crm/Add_Enquirey_page.dart';
import 'package:crm/Profile_page.dart';
import 'package:crm/Responsive_layout/constants.dart';
import 'package:flutter/material.dart';
class Mobile_Scaffold extends StatefulWidget {
  const Mobile_Scaffold({super.key});

  @override
  State<Mobile_Scaffold> createState() => _Mobile_ScaffoldState();
}

class _Mobile_ScaffoldState extends State<Mobile_Scaffold> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar:   AppBar(
        backgroundColor: Colors.blue[400],
        title: const Text('Home'),
        actions:[
          InkWell(
            onTap: (){
              Navigator.push(context, MaterialPageRoute(builder: (context) => const Profile(),));
            },
              child: Image.asset('assets/drawable/emp_profile.png',height: 40,width: 40,color: Colors.black54,)),
          const SizedBox(width: 10)
        ],
      ),
      backgroundColor: mydefaltbackground,
      drawer: myDrawer,
      floatingActionButton: FloatingActionButton(
        onPressed: (){
          Navigator.push(context, MaterialPageRoute(builder: (context) => const AddEnquiry(),));
        },
        child: Icon(Icons.add),
        backgroundColor: Colors.grey[300],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,

      body: const Center(
      ),
      bottomNavigationBar: myBottomNavigationBar(context) ,
    );
  }
}
