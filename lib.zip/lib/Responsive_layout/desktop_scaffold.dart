import 'package:crm/Responsive_layout/constants.dart';
import 'package:flutter/material.dart';
class Desktop_Scaffold extends StatefulWidget {
  const Desktop_Scaffold({super.key});

  @override
  State<Desktop_Scaffold> createState() => _Desktop_ScaffoldState();
}

class _Desktop_ScaffoldState extends State<Desktop_Scaffold> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: mydefaltbackground,
        appBar:   AppBar(
          backgroundColor: Colors.blue[400],
          title: const Text('Home'),
          actions:[
            Image.asset('assets/drawable/emp_profile.png',height: 40,width: 40,color: Colors.black54,),
            const SizedBox(width: 10)
          ],
        ),
        bottomNavigationBar: myBottomNavigationBar(context),
        body: Row(
        children: [
           myDrawer,
        ],

      )
    );
  }
}
