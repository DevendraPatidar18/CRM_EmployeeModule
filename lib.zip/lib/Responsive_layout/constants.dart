
import 'package:crm/Assingned_Enquires_page.dart';
import 'package:crm/Home_page.dart';
import 'package:crm/View_product_services.dart';
import 'package:crm/Update_Enquires_page.dart';


import 'package:flutter/material.dart';
// Widget myAppBar(){
//   return Scaffold(
//     appBar: AppBar( backgroundColor: Colors.blue[400],
//       title: Text(),
//       actions: <Widget>[
//     Image.asset('assets/drawable/emp_profile.png',height: 40,width: 40,color: Colors.black54,),
//       const SizedBox(width: 10,)
//       ],
//     ),
//   );


// class MyApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       home: Scaffold(
//         appBar: myAppBar,
//         drawer: myDrawer,
//         body: const Center(
//         ),
//       ),
//     );
//   }
//}

    var mydefaltbackground = Colors.grey[100];

    var myDrawer = Drawer(
      backgroundColor: Colors.grey[250],
      child: const Column(children: [
        DrawerHeader(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.account_box,
                color: Colors.blue,
              ),
              Text(
                'More',
                style: TextStyle(
                  color: Colors.blue,
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
            ],
          ),
        ),
        ListTile(
          leading: Icon(Icons.call),
          title: Text(
            'Call History',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
        ListTile(
          leading: Icon(Icons.interests_outlined),
          title: Text(
            'View Customer Interests',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
        ListTile(
          leading: Icon(Icons.feedback_outlined),
          title: Text(
            'Client Feedback',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
        ListTile(
          leading: Icon(Icons.report_outlined),
          title: Text(
            'Report',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
      ]),
    );

class Bottomnaviagtionbar extends StatelessWidget {
  const Bottomnaviagtionbar({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      bottomNavigationBar: myBottomNavigationBar(context),

    );
  }
}

Widget myBottomNavigationBar(BuildContext context) {
  return Container(
    height: 60,
    decoration: const  BoxDecoration(
      color: Colors.blue,
      borderRadius: BorderRadius.only(
        topLeft: Radius.circular(15),
        topRight: Radius.circular(15),
      ),
    ),
    child:  Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        InkWell(
          onTap: (){
            Navigator.push(context, MaterialPageRoute(builder: (context) => const Home(),));
          },
          child: const Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.home),
              SizedBox(height: 4),
              Text('Home'),
            ],
          ),
        ),
        InkWell(
          onTap: ()
          {
            Navigator.push(context, MaterialPageRoute(builder: (context) => const View_product(),));
          },
          child: const Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.view_in_ar_rounded),
              SizedBox(height: 4),
              Text('View'),
            ],
          ),
        ),
        InkWell(
          onTap: (){
            Navigator.push(context, MaterialPageRoute(builder: (context) => const Update(),));
          },
          child: const Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.call),
              SizedBox(height: 4),
              Text('Call'),
            ],
          ),
        ),
        InkWell(
          onTap: (){
            Navigator.push(context, MaterialPageRoute(builder: (context) => const Assigned_Enquires()));
          },
          child: const  Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.add_circle_outline_sharp),

               SizedBox(height: 4),
               Text('Enquiry'),
            ],
          ),
        ),
      ],
    ),
  );
}
