import 'package:crm/Responsive_layout/constants.dart';
import 'package:flutter/material.dart';
class Tablet_Scaffold extends StatefulWidget {
  const Tablet_Scaffold({super.key});

  @override
  State<Tablet_Scaffold> createState() => _Tablet_ScaffoldState();
}

class _Tablet_ScaffoldState extends State<Tablet_Scaffold> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:   AppBar(
        backgroundColor: Colors.blue[400],
        title: const Text('Home'),
        actions:[
          Image.asset('assets/drawable/emp_profile.png',height: 40,width: 40,color: Colors.black54,),
          const SizedBox(width: 10)
        ],
      ),
      backgroundColor: mydefaltbackground,
      drawer: myDrawer,
      bottomNavigationBar: myBottomNavigationBar(context),
    );
  }
}
