import 'package:crm/Responsive_layout/constants.dart';
import 'package:flutter/material.dart';
class Assigned_Enquires extends StatefulWidget {
  const Assigned_Enquires({super.key});

  @override
  State<Assigned_Enquires> createState() => _Assigned_EnquiresState();
}

class _Assigned_EnquiresState extends State<Assigned_Enquires> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:   AppBar(
        backgroundColor: Colors.blue[400],
        title: const Text('Assigned Enquires'),
        actions:[
          Image.asset('assets/drawable/emp_profile.png',height: 40,width: 40,color: Colors.black54,),
          const SizedBox(width: 10)
        ],
      ),
      drawer: myDrawer,
      body: const Center(
        child: Text('Assigned Enquires Under Development'),
      ),
      bottomNavigationBar: myBottomNavigationBar(context),
    );
  }
}
