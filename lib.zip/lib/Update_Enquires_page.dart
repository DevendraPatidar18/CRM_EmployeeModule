import 'package:crm/Responsive_layout/constants.dart';
import 'package:flutter/material.dart';
class Update extends StatelessWidget {
  const Update({super.key});

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar:   AppBar(
        backgroundColor: Colors.blue[400],
        title: const Text('Update Enquires'),
        actions:[
          Image.asset('assets/drawable/emp_profile.png',height: 40,width: 40,color: Colors.black54,),
          const SizedBox(width: 10)
        ],
      ),
      drawer: myDrawer,
      body: const  Center(
        child: Text('Update Enquires Under Development'),
      ),
      bottomNavigationBar: myBottomNavigationBar(context),
    );

  }
}
