import 'package:flutter/material.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.blue[400],
        title: const Text('Profile'),
      ),
      body: Container(

        padding: const EdgeInsets.only(top: 40,right: 5,left: 5),
        child: Column(
          crossAxisAlignment:CrossAxisAlignment.start,
          children: [
            const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircleAvatar(
                    radius: 50,
                    backgroundImage:  AssetImage(
                      'assets/drawable/emp_profile.png',

                    ),
                  )

            ]),
            SizedBox(height: 40),
             ListTile(
              tileColor: Colors.grey[300],
              leading: Icon(Icons.person),
              title: Text('',style: TextStyle(fontWeight: FontWeight.w600),),
              subtitle: Text('Name'),
            ),
            const SizedBox(height: 1),
             ListTile(
              tileColor: Colors.grey[300],
               leading: Icon(Icons.perm_identity),
              title: Text('',style: TextStyle(fontWeight: FontWeight.w600),),
              subtitle: Text('Id'),
            ),
            const SizedBox(height: 1),
            ListTile(
              tileColor: Colors.grey[300],
              leading: Icon(Icons.accessibility),
              title: Text('',style: TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text('Role'),
            ),
            const SizedBox(height: 1),
            ListTile(
              tileColor: Colors.grey[300],
              title: Text('',style: TextStyle(fontWeight: FontWeight.w600),),
              subtitle: Text('Experties'),
            ),


          ],
        ),
      ),
    );
  }
}
