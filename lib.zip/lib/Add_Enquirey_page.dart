

import 'package:flutter/material.dart';
class AddEnquiry extends StatefulWidget {
  const AddEnquiry({super.key});

  @override
  State<AddEnquiry> createState() => _AddEnquiryState();
}

class _AddEnquiryState extends State<AddEnquiry> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[50],
        appBar: AppBar(
          backgroundColor: Colors.blue[400],
          title: const Text('Add Enquiry'),

        ),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(20),
          child:  Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 20),
              const TextField(
                style: TextStyle(),
                decoration: InputDecoration(
                  prefixIcon: Icon(
                    Icons.perm_identity,
                  ),
                  border: OutlineInputBorder(),
                  counterStyle: TextStyle(color: Colors.white),
                  labelText: 'Customer Name',
                  labelStyle: TextStyle(),
                ),
              ),
              const SizedBox(height: 30.0),
              const TextField(
                keyboardType: TextInputType.emailAddress,
                style: TextStyle(),
                decoration: InputDecoration(
                  prefixIcon: Icon(
                    Icons.email_rounded,
                  ),
                  border: OutlineInputBorder(),
                  labelText: 'Customer Email',
                  labelStyle: TextStyle(),
                ),
              ),
              const SizedBox(height: 30),
              const TextField(
                keyboardType: TextInputType.text,
                style: TextStyle(),
                decoration: InputDecoration(
                  prefixIcon: Icon(
                    Icons.call,
                  ),
                  border: OutlineInputBorder(),
                  labelText: 'Contact Number',
                  labelStyle: TextStyle(),
                ),
              ),
              const SizedBox(height: 30),
              const TextField(
                keyboardType: TextInputType.text,
                style: TextStyle(),
                decoration: InputDecoration(
                  prefixIcon: Icon(
                    Icons.update,
                  ),
                  border: OutlineInputBorder(),
                  labelText: 'Status',
                  labelStyle: TextStyle(),
                ),
              ),
              const SizedBox(height: 30),
              const TextField(
                keyboardType: TextInputType.text,
                style: TextStyle(),
                decoration: InputDecoration(
                  prefixIcon: Icon(
                    Icons.source_outlined,
                  ),
                  border: OutlineInputBorder(),
                  labelText: 'Source',
                  labelStyle: TextStyle(),
                ),
              ),
              const SizedBox(height: 30),
              const TextField(
                keyboardType: TextInputType.text,
                style: TextStyle(),
                decoration: InputDecoration(
                  prefixIcon: Icon(
                    Icons.add_comment_outlined,
                  ),
                  border: OutlineInputBorder(),
                  labelText: 'Reference',
                  labelStyle: TextStyle(),
                ),
              ),
              const SizedBox(height: 30),
              const TextField(
                keyboardType: TextInputType.text,
                style: TextStyle(),
                decoration: InputDecoration(
                  prefixIcon: Icon(
                    Icons.production_quantity_limits,
                  ),
                  border: OutlineInputBorder(),
                  labelText: 'Enquired For',
                  labelStyle: TextStyle(),
                ),
              ),
              const SizedBox(height: 30),
              const TextField(
                keyboardType: TextInputType.number,
                style: TextStyle(),
                decoration: InputDecoration(
                  prefixIcon: Icon(
                    Icons.perm_identity,
                  ),
                  border: OutlineInputBorder(),
                  labelText: 'Your Id',
                  labelStyle: TextStyle(),
                ),
              ),
              const SizedBox(height: 35),
              ElevatedButton(onPressed: (){}, child: const Text('Add Enquiry',style: TextStyle(color: Colors.black),),)
            ],
          ),
        ),
      )
    );
  }
}
